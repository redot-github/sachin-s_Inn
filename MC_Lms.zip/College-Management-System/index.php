
	<?php include('common/header.php') ?>
	<div class="home-div"></div>
		<div class="w-100 in-ad-ap">
			<div class="row m-auto text-center">
				<div class="col-md-4"><h3>INTRODUCING-MC</h3></div>
				<div class="col-md-4"><h3>ADMISSION POLICY</h3></div>
				<div class="col-md-4"><h3>APPLY NOW</h3></div>
			</div>
		</div>
		<div class="paragraph">
	
			<center>
			<p>
			
			The Madura College (Autonomous), is an academic institution which stands like a towering titan between centuries. It has a hoary past spanning a century and a quarter. It has served the cause of higher education with dedication all these decades. The College offers <b> 21 Under-Graduate Programmes, 13 Post-Graduate Programmes, 8 M.Phil. Programmes and 9 Ph.D. Programmes </b>
			The history of the college reads like a romantic tale.
		</p>
			</center>
			
		</div>
	<?php include('common/cards.php') ?>
	<?php include('common/footer.php') ?>
</body>
</html>

