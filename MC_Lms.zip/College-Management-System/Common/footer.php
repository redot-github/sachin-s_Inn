<footer>
  <div class="footer-top">
    <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12 segment-one md-mb-30 sm-mb-30">
            <h3>Madura College</h3>
            <p> The Madura College (Autonomous), is an academic institution that stands like a towering titan between centuries, A distinguished institution with a hoary past spanning a century.
            </p>
          </div>
          <div class="col-md-2 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>Quick Links</h2>
            <ul>
              <li><a href="">About MC</a></li>
              <li><a href="">Admissions Policy</a></li>
              <li><a href="">Apply for Admission</a></li>
              <li><a href="">Contact Us</a></li>
            </ul>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>UNDERGRADUATE PROGRAMS</h2>
            <ul>
              <li><a href="">B.Sc.Computer science</a></li>
              <li><a href="">B.Sc.Information technology</a></li>
              <li><a href="">B.Sc. Micro-biology</a></li>
              <li><a href="">Bsc.Biotechnology</a></li>
              <li><a href="">B.com</a></li>
              <li><a href="">Bachelors of Business Administration</a></li>
            </ul>
          </div>  
          <div class="col-md-3 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>CONTACT DETAILS</h2>
              <p>Address:The Madura College
(Autonomous),
Vidya Nagar,T.P.K. Road,
Madurai - 625 011
Tamilnadu, India

</p>
              <p>Telephones:9363233228

</p>
              <p>E-mail:office@maduracollege.edu.in</p>
        </div>
      </div>
    </div>
    </div>
  <p class="footer-bottom-text">CopyRights © Created by Priyadharshini @ REDOT SOLUTIONS 2024</p>
</footer>